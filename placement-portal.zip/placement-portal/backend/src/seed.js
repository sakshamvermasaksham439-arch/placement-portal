require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  for (const u of [
    { name: 'TPO Admin', email: 'admin@demo.com', password: 'Admin@123', role: 'admin' },
    { name: 'Recruiter Ravi', email: 'recruiter@demo.com', password: 'Recruit@123', role: 'recruiter', company: 'Acme Tech' },
    { name: 'Alumni Anita', email: 'alumni@demo.com', password: 'Alumni@123', role: 'alumni', company: 'Acme Tech' },
  ]) if (!(await User.findOne({ email: u.email }))) await User.create(u);
  console.log('Seeded demo users'); process.exit(0);
})();
